//
//  ToDo.swift
//  toDoList
//
//  Created by scholar on 8/12/22.
//

import UIKit

class ToDoClass {
    var description = ""
    var important = false
    }
