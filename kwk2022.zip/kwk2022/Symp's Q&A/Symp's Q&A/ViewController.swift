//
//  ViewController.swift
//  Symp's Q&A
//
//  Created by scholar on 8/11/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var clickMe: UIButton!
    
    @IBOutlet weak var scoreLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        scoreLabel.text =
        String(Symp.score)
        // Do any additional setup after loading the view.
    }


}

