//
//  Symp.swift
//  Symp's Q&A
//
//  Created by scholar on 8/12/22.
//

import Foundation


class Symp {
    static var name = "Symphany"
    static var score = 0
}
